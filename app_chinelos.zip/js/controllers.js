angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

})
   
.controller('soladosCtrl', function($scope) {

})
   
.controller('cabidesCtrl', function($scope) {

})
   
.controller('tirasCtrl', function($scope) {

})
 